package com.bigzaddy.zaddychat

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 27, 26)
    private val accent = Color.rgb(22, 160, 133)
    private val white = Color.WHITE
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showWelcome()
    }

    private fun baseLayout(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(bg)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
    }

    private fun title(text: String, size: Float): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(white)
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            gravity = Gravity.CENTER
        }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            setTextColor(white)
            setBackgroundColor(accent)
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun showWelcome() {
        root = baseLayout()
        root.addView(title("ZADDY CHAT", 34f))
        root.addView(title("Connect. Chat. Stay close.", 16f), margin(12, 0, 12, 30))
        root.addView(button("Create account") { showForm(true) }, matchWrap(0, 12))
        root.addView(button("Log in") { showForm(false) }, matchWrap(0, 8))
        root.addView(title("Your conversations start here.", 13f), margin(20, 0, 0, 0))
        setContentView(root)
    }

    private fun showForm(register: Boolean) {
        root = baseLayout()
        root.addView(title(if (register) "Create your account" else "Welcome back", 26f),
            margin(0, 0, 0, 24))

        val name = if (register) field("Your name") else null
        val email = field("Email address")
        val password = field("Password").apply {
            inputType = 0x00000081
        }

        if (name != null) root.addView(name, matchWrap(0, 10))
        root.addView(email, matchWrap(0, 10))
        root.addView(password, matchWrap(0, 18))
        root.addView(button(if (register) "Continue" else "Log in") {
            showMessage("This is the first app screen prototype. Account sign-in will be connected to Firebase in the next build.")
        }, matchWrap(0, 10))
        root.addView(button("Back") { showWelcome() }, matchWrap(0, 8))
        setContentView(root)
    }

    private fun field(hintText: String) = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.LTGRAY)
        setTextColor(white)
        textSize = 16f
        setSingleLine(true)
        setPadding(18, 12, 18, 12)
        setBackgroundColor(Color.rgb(24, 48, 46))
    }

    private fun showMessage(message: String) {
        root.removeAllViews()
        root.addView(title("ZADDY CHAT", 28f), margin(0, 0, 0, 18))
        root.addView(title(message, 16f), margin(0, 0, 0, 24))
        root.addView(button("Back to welcome") { showWelcome() }, matchWrap(0, 8))
        setContentView(root)
    }

    private fun matchWrap(top: Int, bottom: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(0, top, 0, bottom) }

    private fun margin(left: Int, top: Int, right: Int, bottom: Int): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { setMargins(left, top, right, bottom) }
}
