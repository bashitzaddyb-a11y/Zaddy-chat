ZADDY CHAT — Android starter project
====================================

This is the FIRST native Android starter build, not the finished Zangi-like app
and not an APK. It contains a welcome screen plus draft create-account/login
screens. Authentication is not connected yet; the next development stage is
Firebase Authentication, followed by profiles and real-time messages.

Project settings
----------------
Package/application ID: com.bigzaddy.zaddychat
Language: Kotlin
Minimum Android: 6.0 (API 23)
Compile SDK: 35
Gradle: 8.9
Android Gradle Plugin: 8.7.3

Important
---------
1. Do not put passwords, service-account JSON files, or private keys in this project.
2. Firebase will be connected in a later step using your own google-services.json.
3. To build an APK, open/import this folder in a compatible Android development
   environment with Android SDK 35 and JDK 17 installed, then build the app.
4. If your phone IDE cannot open this project, send a screenshot of the error.
